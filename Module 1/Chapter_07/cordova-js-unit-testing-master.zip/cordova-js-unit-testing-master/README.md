Weather Application
===
This is a sample Apache Cordova project which utilizes Jasmine unit testing framework in order to unit test the application logic.