MegaApp
===
Mega App is a complete Cordova App that uses some of Cordova plugins to build a Memo Application. Memo app allows you to save your audible memos (such as talks, lectures, reminders, business meeting, kids voice, …etc) and also your visual memos (such as photos) using an easy-to-use and responsive user interface. It allows you to also manage all your memos from a single unified listing.
