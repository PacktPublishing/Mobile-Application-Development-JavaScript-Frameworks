/** Automatically generated file. DO NOT MODIFY */
package com.jsmobile.megaapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}