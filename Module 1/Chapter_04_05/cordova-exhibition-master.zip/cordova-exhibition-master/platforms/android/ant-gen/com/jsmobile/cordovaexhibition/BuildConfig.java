/** Automatically generated file. DO NOT MODIFY */
package com.jsmobile.cordovaexhibition;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}