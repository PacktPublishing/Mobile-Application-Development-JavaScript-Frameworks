Cordova Exhibition
===
Cordova Exhibition project aims at showing the Apache Cordova significant plugins in a working Demo. Cordova Exhibition is supported on Android, iOS and Windows Phone 8 platforms.